# Calculation Center: complete implementation prompt

Copy everything below the line into your coding agent. Keep the `screens/` folder next to this file so the agent can open the images. If your agent doesn't read images, attach the PNGs to the chat with it.

---

You are working in an existing application: "Strategical Financial Resource Management". It has an Angular + PrimeNG frontend and a Spring Boot + Oracle backend. Implement the complete Calculation Center user flow, the fixes, and the UI refresh described below.

## Ground rules

- Inspect the existing implementation first. That means the routes, components, services, DTOs, controllers, status enums, polling logic and styles for the Calculation Center. Then make the code changes.
- Do not stop at a plan or recommendations.
- Follow the project's existing architecture, naming, styling and API conventions. Reuse what exists; extend it rather than creating parallel versions. Avoid unrelated refactoring.
- Do not invent backend activity names, readiness criteria or execution steps. Use what the backend and calculation engine actually provide. Any names below are illustrative.
- Check the installed PrimeNG version. PrimeNG ≤17 uses `p-dropdown` (`DropdownModule`); 18+ renamed it to `p-select` (`SelectModule`). Check the Angular version too: on Angular <17, use `*ngIf`/`*ngFor` instead of `@if`/`@for`.
- If something in this spec conflicts with how the backend really works, follow the backend's real behaviour. Say what you changed and why in your final report.

---

## 0. Target screens (visual reference)

These mockups show the intended result for each step in §1. Match their layout, states and wording.

- **Placeholders:** bracketed text such as `[Run ID]` or `[Next engine activity]` stands for real backend data.
- **Sample data:** the readiness criteria names, times and output columns are illustrative.

| Step | Screen |
|---|---|
| 1 | Calculation Center: pick a calculation |
| 2 | Calculation opened: select a scenario |
| 3 | Scenario selected: readiness in progress |
| 4 | All criteria met: Calculate enabled |
| 5 | Back on cards: selected scenario and readiness shown |
| 6 | Calculation triggered: live updates |
| 7 | Back on cards: running, View progress |
| 8 | Completed: Reset to start a new calculation |
| 9 | Recent activity: select an item to see its status |

**Step 1 — Calculation Center**
![Step 1](screens/step-1.png)

**Step 2 — Calculation opened, select a scenario**
![Step 2](screens/step-2.png)

**Step 3 — Readiness in progress**
![Step 3](screens/step-3.png)

**Step 4 — All criteria met, Run enabled**
![Step 4](screens/step-4.png)

**Step 5 — Back on the cards: scenario + readiness on the card**
![Step 5](screens/step-5.png)

**Step 6 — Calculation running, live activity**
![Step 6](screens/step-6.png)

**Step 7 — Back on the cards: Running + View progress**
![Step 7](screens/step-7.png)

**Step 8 — Completed, output, Reset & start new calculation**
![Step 8](screens/step-8.png)

**Step 9 — Recent activity drawer**
![Step 9](screens/step-9.png)

---

## 1. Target user flow (implement exactly this)

**Step 1 — Calculation Center (homepage).**
- Cards are grouped as "Tax Calculations" and "Standalone Calculations".
- Keep the filter label buttons All / Tax / Standalone. Show counts on them, e.g. "All 5", "Tax 2", "Standalone 3".
- Keep search.
- Every card shows its live status (see §4) and has an action button.
- A "Recent activity" panel sits on the right.

**Step 2 — Open a calculation.**
- Clicking a card's button opens the calculation detail screen (existing route, e.g. `#/CALC_CENTER/:id`).
- With no scenario selected:
  - The Scenario dropdown shows the placeholder "Select a scenario".
  - Readiness shows "Readiness not checked — pick a scenario and readiness is checked automatically".
  - "Run calculation" is disabled, with the hint "Select a scenario first."
  - Reset is disabled.

**Step 3 — Scenario selected → readiness runs automatically.**
- Selecting a scenario immediately starts the readiness check.
- While it runs:
  - Show "Checking readiness for {scenario}…" with a spinner.
  - List each readiness criterion the backend returns, showing a spinner while it is pending and "Met" / "Not met" when it resolves.
  - Show a count, e.g. "1 of 2 checked".
  - The stepper's Readiness phase shows "Checking…".
  - The Run button shows "Waiting for readiness…" and is disabled.
- Changing the scenario or pressing Reset cancels the in-flight check.

**Step 4 — All criteria met → Run enabled.**
- Show "All criteria met · N of N met" and a "Ready to run" badge next to the title.
- "Run calculation" is enabled only when every criterion is met.
- If any criterion fails, show which ones failed and why. Run stays disabled.
- If the readiness service errors, show ONE amber message: "We couldn't check readiness", with a "Retry check" button. Do not use red "Failed", and do not repeat the message in several places.

**Step 5 — Back on the cards (breadcrumb, sidebar or browser back).**
- The card for that calculation shows the selected scenario as a chip, plus the readiness status: "Ready to run", "Checking readiness…" (if still running), "Readiness not met" or "Readiness not verified".
- The readiness check must keep running after the user leaves the detail page. Coming back to the detail page must restore the selected scenario and readiness result.

**Step 6 — Run triggered → live updates on the detail page.**
- The scenario dropdown and Reset are locked, with the hint "Scenario and Reset are locked while this run is active."
- The stepper shows Readiness = Completed, Validation Execution = Running, Result Aggregation = Not started. It advances only from real backend phase state.
- Live activity shows only activities the backend reports as started.
- The running activity shows its real label and description, then an animated spinner DIRECTLY BENEATH it, then "In progress… started {time}".
- Completed activities stay as history with a check and time.
- The Output section is hidden or neutral: "Results appear here when this run completes." It never shows previous output and never shows a red error during the run.

**Step 7 — Back on the cards while running.**
- The card shows "Running · {current phase}", the scenario chip, the current activity label as the meta line, and an animated progress bar on the card.
- Its button becomes a primary "View progress", which navigates to the detail page for that calculation. That page resumes live tracking of the same run ID.
- The status keeps updating on the homepage (polling) until the run reaches a terminal state.

**Step 8 — Completed.**
- The badge reads "Completed".
- Show a run summary (Run ID, Scenario, Started, Duration, Run by), all phases completed, and the activity history.
- Show the output table for THIS run ID, with a "Download Excel" button using the existing export.
- To run again, the user clicks Reset (or "Reset & start new calculation"). This clears the scenario and readiness and returns to the Step 2 state. Selecting a scenario again re-runs readiness (Step 3).
- On failure or cancellation, show the outcome clearly. Downstream phases are not marked completed and no stale output is shown.

**Step 9 — Recent activity.**
- The homepage "Recent activity" panel lists recent readiness checks and runs, newest first. Each item shows the calculation name, status, scenario and time.
- Clicking an item opens a right-side drawer (PrimeNG `p-sidebar` / `p-drawer`) with that activity's status:
  - Run ID and scenario
  - Started and finished times, duration, and who ran it
  - Phase statuses and the activity list
  - Buttons: "Open calculation", "View progress" while running, and "Download output" when completed
- If the selected activity is still running, the drawer updates live.

---

## 2. Bugs to fix (observed)

1. **Card status lost on return.** After selecting a scenario (readiness checked) and clicking the "Calculation Center" breadcrumb, every card shows "Select context to check readiness". The selected scenario, readiness result and running state are lost.
   - Likely cause (verify): this state lives only in the detail component, and the homepage builds status from the calculation list API alone.
2. **No way to reset the scenario.** Add Reset (see §5).
3. **Red error during a run.** "Execution history could not be loaded." appears in red under Calculation Output while a run is active. Do not request history during an active run. When idle and history genuinely fails, show a neutral one-line message with "Try again".
4. **Earlier live-activity issues.** If any are still present, fix them:
   - The full predefined activity list is shown at run start.
   - "Not applicable" rows appear with success icons.
   - A synthetic "Waiting…" message is stored as a completed activity.
   - Progress shows 0% when no real progress exists.
   - The spinner is not under the running activity.
   - Result Aggregation is marked complete while validation is still running.
   - Stale output from a previous run is shown.
   - A polling response from an old run overwrites the current run.

---

## 3. State model and data flow

### 3.1 Frontend: one shared store (root-provided service)

Create `CalculationContextStore` (or extend an existing shared service). It must be `providedIn: 'root'`, keyed by calculation ID, and hold:

```
calculationId
scenario: string | null
readiness: 'IDLE' | 'CHECKING' | 'PASSED' | 'NOT_MET' | 'ERROR'
criteria: { id, label, status: 'PENDING'|'MET'|'NOT_MET', message? }[]
readinessMessage?: string
runId?: string | null
runState: 'NONE' | 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED'
updatedAt: number
```

- The store, not the component, starts and owns the readiness request: `store.selectScenario(calcId, scenario)`. That way it keeps running after navigation.
- Keep one `switchMap` stream per calculation ID, so a new selection or a reset cancels the previous request.
- Persist to `sessionStorage` so a browser refresh restores state. Wrap reads and writes in try/catch. Clear it on logout.
- The detail page and the homepage both read from the store. The detail page restores from it on init. If `runId` is active, it resumes polling that run ID.
- The server is the source of truth for runs. The store is the source of truth for a selected-but-not-yet-run scenario and its readiness.

### 3.2 Backend contract (extend existing endpoints where possible)

**Readiness.** The response must include per-criterion results:

```json
{ "calculationTypeId": "OCI_TAX", "scenario": "QMMF_202512_IBL", "ready": true,
  "criteria": [ { "id": "...", "label": "...", "status": "MET", "message": null } ] }
```

**Run status / live activity.**
- Use one consistent DTO for run ID, overall status, current phase, phase statuses, actual started activities (stable ID, label, description, order, status, start/end times, failure details), and `outputAvailable`.
- Return actual execution events, not activity definitions. NOT_APPLICABLE/SKIPPED definitions must never appear as executed activities.
- An activity is not COMPLETED before it completes. Aggregation stays NOT_STARTED until it starts. Success is reported only after aggregation finishes and the output is committed.
- Progress is `null` unless the engine reports real progress.

**Latest run per calculation (for cards).**
- `GET /api/calculation-center/latest-runs` returns, per calculation type: `calculationTypeId, runId, scenario, status, currentPhase, currentActivityLabel, startedAt, completedAt, runBy`.
- Oracle example — adapt table and column names, and match how runs are scoped (per user or global):

```sql
SELECT * FROM (
  SELECT r.calc_type_id, r.run_id, r.scenario_code, r.status, r.current_phase,
         r.current_activity_label, r.started_at, r.completed_at, r.created_by,
         ROW_NUMBER() OVER (PARTITION BY r.calc_type_id ORDER BY r.created_at DESC) rn
  FROM calc_run r)
WHERE rn = 1
```

**Recent activity.** `GET /api/calculation-center/recent-activity?limit=10` returns readiness checks and runs, newest first. Each item has: `type (READINESS|RUN), calculationTypeId, calculationName, runId?, scenario, status, timestamp`. Persist readiness check results if they are not stored today; if that isn't feasible, show runs only and say so in the report.

**Output.** Fetch it by run ID only, and only when `status = COMPLETED && outputAvailable`.

**Caching.** All status endpoints return `Cache-Control: no-store`.

### 3.3 Polling and subscriptions

- Detail page: poll (or subscribe to) the current run ID only. Use `switchMap` keyed by run ID. Ignore responses whose run ID ≠ the active run ID, and ignore out-of-order responses (compare `updatedAt`/sequence). Merge activities by stable ID with no duplicates. Stop on a terminal status. Clean up on destroy (`takeUntilDestroyed`).
- Homepage: fetch latest-runs on load. While any run is QUEUED/RUNNING, poll every ~5s; stop when none are active. Refresh recent activity on the same cadence.
- Transient network errors must not mark anything completed or failed. Keep the last known state, retry with backoff, and show a subtle "Reconnecting…" only if failures persist.

---

## 4. Card status rules (homepage)

Status precedence for each card:

| Priority | Condition | Pill | Scenario chip | Meta line | Button |
|---|---|---|---|---|---|
| 1 | Server run QUEUED/RUNNING | "Running · {phase}" (blue, spinner) + animated bar on card | run scenario | current activity label | **View progress** (primary) |
| 2 | Store readiness CHECKING | "Checking readiness…" (spinner) | selected scenario | "Readiness check in progress" | Open |
| 3 | Store readiness PASSED | "Ready to run" (green) | selected scenario | "All criteria met" | Open |
| 4 | Store readiness NOT_MET | "Readiness not met" (amber) | selected scenario | first failing criterion | Open |
| 5 | Store readiness ERROR | "Readiness not verified" (amber) | selected scenario | — | Retry / Open |
| 6 | Last server run COMPLETED | "Completed" | run scenario | "Run {id} · {duration}" | View results |
| 7 | Last server run FAILED/CANCELLED | "Last run failed" / "Cancelled" | run scenario | "Run {id}" | Open |
| 8 | Nothing | "No scenario selected" (grey) | — | "Open to pick a scenario" | Open |

Use the same status vocabulary on the homepage and the detail page.

---

## 5. Reset behaviour

- Put a text button labelled "Reset" (`pi pi-refresh`) at the right end of the Scenario label row. Also enable `showClear` on the dropdown; clearing must behave exactly like Reset.
- Enabled when a scenario is selected and no run is active. This includes while readiness is checking, and after a run has completed.
- Disabled while a run is QUEUED/RUNNING, with a tooltip explaining why.
- On Reset:
  1. Clear the dropdown.
  2. Cancel any in-flight readiness request.
  3. Clear the readiness result, criteria and messages.
  4. Disable Run.
  5. Reset the stepper to "Not started" for the new context.
  6. Hide the previous output from the active view; it stays reachable through Recent activity / run history.
  7. Remove the store entry so the card shows "No scenario selected" (or the last completed run per §4).
  8. Show the toast "Scenario cleared".
  9. Never delete server run history.
- After Reset, selecting a scenario triggers readiness again (Step 3).
- On the Completed screen, a primary "Reset & start new calculation" button does the same thing.

---

## 6. UI refresh (modern, keep cards and label buttons)

Reference mockups: the screenshots in §0 (`screens/step-1.png` … `step-9.png`). Implement with PrimeNG components and the app's theme variables where they exist. The values below are the target look.

**Base**
- Page background `#F4F6FA`; surfaces white with a `1px #E3E8EF` border.
- Card radius 16px, with shadow `0 1px 2px rgba(16,27,44,.04), 0 8px 24px rgba(16,27,44,.05)`.
- Primary `#0B5CD5`. Keep the existing navy sidebar.
- Text `#101B2C`, secondary text `#4A5565`. Status colours: green `#146436` on `#DDF1E4`, blue `#0A4BAE` on `#DCE8FC`, amber `#7A4300` on `#FFF0D9`, grey `#3B4757` on `#E9EDF2`.
- Scenario names and run IDs in a monospace font.

**Homepage**
- Header: breadcrumb, H1 "Calculation Center", subtitle, and search on the right.
- Pill filter buttons with counts and a category colour dot.
- A responsive card grid (`repeat(auto-fill, minmax(300px, 1fr))`) with the Recent activity panel to the right. It stacks below on narrow screens.

**Card**
- Top: tinted icon tile (blue for Tax, teal for Standalone), name, "Context · Scenario", and the star button (keep it). Below that, the description clamped to 2 lines.
- Bottom status band, tinted by state: status pill + scenario chip, then the meta line + action button. Running cards get a 3px indeterminate bar on the band's top edge.

**Detail page**
- Two columns.
- Left, "Run setup" card: Scenario label + Reset, dropdown, readiness block (criteria list), full-width Run button (48px), and a helper line.
- Right: an "Execution" card (segmented 3-phase stepper with animated running segment, then live activity / history) and an "Output" card.
- A status badge next to the page title.

**Accessibility**
- Real buttons and links, `aria-live="polite"` on live activity, and `aria-label` on icon-only buttons and spinners.
- Status must not rely on colour or animation alone; always show text.
- Respect `prefers-reduced-motion`.

### 6.1 PrimeNG component mapping

Run `npm ls primeng` first and use the matching component names. PrimeNG 18+ renamed `Dropdown` → `Select` and `Sidebar` → `Drawer`, and moved theming to design-token presets. On 16–17, set the colours through the theme's CSS variables.

| UI element | Use |
|---|---|
| Filter label buttons with counts | `p-selectButton` with an item template for the count, or three `p-button`s toggling `[outlined]` |
| Search with icon | `p-iconField` + `p-inputIcon` + `pInputText` (v17+); on older versions, `span.p-input-icon-left` |
| Calculation cards | `p-card` with header/footer templates, or a styled `div` (simpler for the tinted status band) |
| Status pills | `p-tag` with `severity` + icon (warn severity: `"warning"` ≤17, `"warn"` 18+) |
| Scenario chip | `p-chip` or `p-tag` with a monospace class |
| Running bar on card / running stepper segment | `p-progressBar mode="indeterminate"`, 3–6px high |
| Spinner under the running activity | `p-progressSpinner` (small, custom `strokeWidth`) or `<i class="pi pi-spin pi-spinner">` |
| Scenario dropdown | `p-dropdown` (≤17) / `p-select` (18+) with `[showClear]`, `[filter]`, `(onClear)` |
| Reset | `p-button` with `[text]="true"`, `icon="pi pi-refresh"` |
| Readiness criteria | List with `p-tag`/icons, or `p-timeline` |
| Live activity / activity history | `p-timeline` with custom `marker` and `content` templates |
| 3-phase stepper | Custom component (flex + `p-progressBar` segments). Do NOT use `p-steps`/`p-stepper`; they are wizard navigation, not status display. |
| Readiness service error | `p-message severity="warn"` (`"warning"` ≤17) + Retry `p-button` |
| Output placeholder | `p-skeleton` |
| Output table | `p-table` (sorting, filter, paginator) + the existing Excel export |
| Recent activity drawer | `p-sidebar position="right"` (≤17) / `p-drawer position="right"` (18+) |
| "Scenario cleared" toast | `p-toast` + `MessageService` |
| Locked Reset hint | `pTooltip` |
| Breadcrumb | `p-breadcrumb` |

Custom CSS is expected for: the tinted card status band, the segmented stepper, placing the spinner directly under the running activity label, and the colour palette in §6.

---

## 7. Reference code (adapt; don't paste blindly)

```ts
// calculation-context.store.ts (sketch)
@Injectable({ providedIn: 'root' })
export class CalculationContextStore {
  private readonly KEY = 'calcCenter.context.v1';
  private readonly state$ = new BehaviorSubject<Record<string, CalcContext>>(this.load());
  private readonly selections = new Map<string, Subject<string | null>>();
  readonly all$ = this.state$.asObservable();

  constructor(private api: CalculationApi) {}

  select(id: string) { return this.state$.pipe(map(s => s[id] ?? empty(id)), distinctUntilChanged((a, b) => a.updatedAt === b.updatedAt)); }
  snapshot(id: string) { return this.state$.value[id] ?? empty(id); }

  /** Starts (or cancels) readiness for a calculation; survives navigation. */
  selectScenario(id: string, scenario: string | null): void {
    this.stream(id).next(scenario);
  }

  reset(id: string): void {
    this.stream(id).next(null);                       // cancels in-flight check
    const { [id]: _, ...rest } = this.state$.value;
    this.commit(rest);
  }

  patch(id: string, p: Partial<CalcContext>) {
    this.commit({ ...this.state$.value, [id]: { ...this.snapshot(id), ...p, calculationId: id, updatedAt: Date.now() } });
  }

  private stream(id: string): Subject<string | null> {
    let s = this.selections.get(id);
    if (!s) {
      s = new Subject<string | null>();
      s.pipe(
        tap(sc => this.patch(id, { scenario: sc, readiness: sc ? 'CHECKING' : 'IDLE', criteria: [], readinessMessage: null })),
        switchMap(sc => !sc ? EMPTY : this.api.checkReadiness(id, sc).pipe(
          map(r => ({ readiness: (r.ready ? 'PASSED' : 'NOT_MET') as ReadinessState, criteria: r.criteria })),
          catchError(() => of({ readiness: 'ERROR' as ReadinessState, criteria: [] })),
        )),
      ).subscribe(r => this.patch(id, r));
      this.selections.set(id, s);
    }
    return s;
  }

  private commit(next: Record<string, CalcContext>) {
    this.state$.next(next);
    try { sessionStorage.setItem(this.KEY, JSON.stringify(next)); } catch {}
  }
  private load() { try { return JSON.parse(sessionStorage.getItem(this.KEY) ?? '{}'); } catch { return {}; } }
}
```

On load, if a persisted entry is still CHECKING, the request was lost with the page. Restart it by calling `selectScenario(id, scenario)`.

```html
<!-- Detail: scenario row -->
<div class="field-head">
  <label for="scenario">Scenario <span class="req">*</span></label>
  <p-button label="Reset" icon="pi pi-refresh" [text]="true" size="small"
            [disabled]="!canReset" (onClick)="onReset()"
            [pTooltip]="runActive ? 'Unavailable while a run is active' : ''" />
</div>
<p-dropdown inputId="scenario" [formControl]="scenarioCtrl" [options]="scenarios"
            optionLabel="name" optionValue="code" placeholder="Select a scenario"
            [filter]="true" [showClear]="canReset" (onClear)="onReset()" styleClass="w-full" />
```

```ts
// Detail: wiring
ngOnInit() {
  const ctx = this.store.snapshot(this.id);
  this.scenarioCtrl.setValue(ctx.scenario, { emitEvent: false });
  if (ctx.runId && ['QUEUED', 'RUNNING'].includes(ctx.runState)) { this.scenarioCtrl.disable({ emitEvent: false }); this.trackRun(ctx.runId); }
  this.scenarioCtrl.valueChanges.pipe(distinctUntilChanged(), takeUntilDestroyed(this.destroyRef))
    .subscribe(sc => this.store.selectScenario(this.id, sc));
}
canRun(ctx: CalcContext) { return !!ctx.scenario && ctx.readiness === 'PASSED' && !this.runActive; }
onReset() {
  if (!this.canReset) return;
  this.scenarioCtrl.setValue(null, { emitEvent: false });
  this.store.reset(this.id);
  this.messageService.add({ severity: 'success', summary: 'Scenario cleared' });
}
```

`toCardStatus(ctx, latestRun)` implements the §4 table. Write it as a pure function with unit tests.

---

## 8. Tests and acceptance criteria

Add or update backend and frontend tests. At least:

1. Selecting a scenario triggers exactly one readiness call; a fast re-selection cancels the previous call.
2. Criteria render per item with pending/met/not-met states. Run is enabled only when all are met.
3. A readiness service error shows one amber message with Retry, no red "Failed", and no duplicate messages.
4. Leaving the detail page during readiness → the card shows "Checking readiness…" and then the final result. The check is not cancelled by navigation.
5. Breadcrumb back after readiness passes → the card shows the scenario chip and "Ready to run". A browser refresh keeps it.
6. Starting a run locks the scenario and Reset. The card shows "Running · {phase}" with "View progress", which opens the live view for the same run ID.
7. Live activity shows only started activities, the spinner sits under the running activity, there are no duplicates on repeated polls, and old or out-of-order responses are ignored.
8. Stepper: aggregation stays pending until it really starts, and all phases complete only on success.
9. Output stays hidden or neutral during the run, there is no red history error, and after completion the output belongs to the current run ID.
10. Reset clears the dropdown, readiness and output view, disables Run, sets the card to "No scenario selected", shows a toast, and keeps the server history. Re-selecting re-runs readiness.
11. Reset and the clear icon are disabled during an active run.
12. Recent activity lists items newest first; clicking one opens the drawer with the correct status, which updates live for a running item.
13. Homepage polling runs only while something is active and stops afterwards; all subscriptions are cleaned up on navigation.
14. Filters (All/Tax/Standalone with counts), search and the star icons still work.

Run the project's unit tests, build and lint. Report exactly what passed and what failed. Do not claim checks you didn't run.

## 9. Deliverables (in your final message)

- Root causes found for each bug in §2.
- Files changed, with the purpose of each.
- API contract changes, with real request/response examples from your implementation.
- The final backend → store → UI state flow, in a few lines.
- The tests and checks you ran, with their results.
- Any remaining limitations or follow-ups. In particular, say whether readiness history is persisted for Recent activity.
